# LotoPy

Descrição.
Gerador de numeros aleatórios para jogos de loterias.
Permite gerar numeros para megasena, lotofacil e quina.
	lotopy:
	    - megasena
	    - quina
	    - lotofacil
	    
## Instalação

Use o gerenciador de pacotes [pip](https://pip.pypa.io/en/stable/) to install package_name

---bash
pip install lotopy

## Autor
Flavio Rabelo
